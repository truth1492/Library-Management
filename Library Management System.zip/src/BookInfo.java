public class BookInfo {
    private int bookid;
    private String bname;
    private String author;
    private int edition;
    private String publisher;
    private int pages;
    private String category;
    
    public BookInfo(int bookid, String bname, String author, int edition, String publisher, int pages, String category) {
        this.bookid = bookid;
        this.bname = bname;
        this.author = author;
        this.edition = edition;
        this.publisher = publisher;
        this.pages = pages;
        this.category = category;
    }
    
    public int getBookid() {
        return bookid;
    }
    
    public String getBname() {
        return bname;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public int getEdition() {
        return edition;
    }
    
    public String getPublisher() {
        return publisher;
    }
    
    public int getPages() {
        return pages;
    }
    
    public String getCategory() {
        return category;
    }
}
